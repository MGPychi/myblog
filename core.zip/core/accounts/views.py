from django.shortcuts import render,redirect
from .forms import SignInForm,ProfileEddit
from .models import Profile
from django.shortcuts import reverse
from django.contrib.auth.models import User
# Create your views here.
def signin(request):
	form = SignInForm()
	if request.method=="POST":
		form = SignInForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect(reverse("login"))
	context={
	'form':form
	}
	return render(request,"signin.html",context)
	
def profile_page(request):
	profile = Profile.objects.get(user=request.user)
	print(profile.user_gender)
	context={
	'profile':profile
	}
	return render(request,"profile.html",context)


def profile_eddit(request):
	profile = Profile.objects.get(user =request.user)
	profile_form  = ProfileEddit(instance=profile)
	if request.method=="POST":
		profile_form = ProfileEddit(request.POST,request.FILES)
		if profile_form.is_valid():

			my_form = profile_form.save(commit=False)
			my_form.user =request.user
			my_form.save()


			return redirect(reverse("blog:home"))
	context={
	"form":profile_form
	}
	return render(request,"profile_eddit.html",context)


def profile_delete(request):
	user = User.objects.get(id=request.user.id)
	user.delete()
	return redirect(reverse("blog:home"))
