from django.db import models
from django.db.models.signals import  post_save
from django.contrib.auth.models import User
# Create your models here.
gender=[
('male',"male"),
("female","female")
]

class Profile(models.Model):
	nikname = models.CharField(max_length=100)
	email = models.CharField(max_length=100)
	user_gender = models.CharField(choices=gender,max_length=100)
	image = models.ImageField(upload_to="images")
	created = models.DateTimeField(auto_now_add=True)
	user = models.OneToOneField(User,on_delete=models.CASCADE)

	def __str__(self):
		return str(self.user.username)


def create_a_profile(sender,instance,created,**kwargs):
	if created:
		print("creaing a profile")
		print(instance)
		pro = Profile.objects.create(user=instance)
		pro.email = instance.email
		pro.save()

post_save.connect(create_a_profile,sender=User)


	
