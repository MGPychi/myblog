from django.urls import path
from . import views
app_name="accounts"

urlpatterns=[
	path("signin/",views.signin,name="signin"),
	path("profile/",views.profile_page,name="profile"),
	path("profile_eddit/",views.profile_eddit,name="profile_eddit"),
	path("profile_delete/",views.profile_delete,name="profile_delete")


]