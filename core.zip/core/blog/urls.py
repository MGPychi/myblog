
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views
app_name='blog'

urlpatterns=[
	path("home/",views.home,name="home"),
	path("post-delete/<int:id>",views.delete_post,name="delete_post")
]
