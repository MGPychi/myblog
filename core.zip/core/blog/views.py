from django.shortcuts import render,reverse,redirect
from .models import Post
from .forms import PostForm
# Create your views here.

def home(request):
	post_form = PostForm(request.POST or None)
	if request.method=="POST":
		my_form = post_form.save(commit=False)
		my_form.authr = request.user
		my_form.save()
		return redirect(reverse("blog:home"))

	data_list = Post.objects.all()
	context={
		'posts':data_list,
		'form':post_form,
	}
	return render(request,'blog/home.html',context)

def delete_post(request,id):
	post = Post.objects.get(id=id)

	if request.user == post.authr:
		post.delete()
		return redirect(reverse("blog:home"))